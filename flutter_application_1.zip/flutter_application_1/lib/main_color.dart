import 'package:flutter/material.dart';

class MainColor {
  static Color primaryColor = const Color.fromARGB(255, 27, 73, 224);
  static Color secondaryColor = const Color.fromARGB(255, 255, 255, 255);
  static Color accentColor = const Color.fromARGB(255, 82, 60, 182);
}